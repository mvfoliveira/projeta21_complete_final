import { Prixquantite } from './prixquantite';

describe('Prixquantite', () => {
  it('should create an instance', () => {
    expect(new Prixquantite()).toBeTruthy();
  });
});
